(() => {
  const hero = document.querySelector('.hero');
  const track = document.querySelector('#heroTrack');
  const slides = track ? [...track.children] : [];
  const dots = document.querySelector('#heroDots');
  let current = 0;
  let rotation;

  const showSlide = (index) => {
    if (!slides.length || !track) return;
    current = (index + slides.length) % slides.length;
    track.style.transform = `translateX(-${current * 100}%)`;
    dots?.querySelectorAll('button').forEach((dot, i) => {
      dot.classList.toggle('active', i === current);
      dot.setAttribute('aria-current', i === current ? 'true' : 'false');
    });
  };

  if (dots && slides.length > 1) {
    slides.forEach((slide, i) => {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.setAttribute('aria-label', `Show offer ${i + 1}`);
      dot.addEventListener('click', () => showSlide(i));
      dots.append(dot);
    });
    document.querySelector('#heroPrev')?.addEventListener('click', () => showSlide(current - 1));
    document.querySelector('#heroNext')?.addEventListener('click', () => showSlide(current + 1));
    const startRotation = () => { clearInterval(rotation); rotation = setInterval(() => showSlide(current + 1), 5500); };
    const stopRotation = () => clearInterval(rotation);
    hero?.addEventListener('mouseenter', stopRotation);
    hero?.addEventListener('mouseleave', startRotation);
    hero?.addEventListener('focusin', stopRotation);
    hero?.addEventListener('focusout', startRotation);
    showSlide(0);
    startRotation();
  }

  const promoTrack = document.querySelector('#promoTrack');
  const promoDots = document.querySelector('#promoDots');
  const promoSlides = promoTrack ? [...promoTrack.children] : [];
  const promoSlider = document.querySelector('.banner-slider');
  let promoIndex = 0;
  let promoRotation;
  const showPromo = (index) => {
    if (!promoTrack || !promoSlides.length) return;
    promoIndex = (index + promoSlides.length) % promoSlides.length;
    promoTrack.style.transform = `translateX(-${promoIndex * 100}%)`;
    promoDots?.querySelectorAll('button').forEach((dot, i) => {
      dot.classList.toggle('active', i === promoIndex);
      dot.setAttribute('aria-current', i === promoIndex ? 'true' : 'false');
    });
  };
  if (promoTrack && promoDots && promoSlides.length > 1) {
    promoSlides.forEach((slide, i) => {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.setAttribute('aria-label', `Show offer ${i + 1}`);
      dot.addEventListener('click', () => showPromo(i));
      promoDots.append(dot);
    });
    document.querySelector('#promoPrev')?.addEventListener('click', () => showPromo(promoIndex - 1));
    document.querySelector('#promoNext')?.addEventListener('click', () => showPromo(promoIndex + 1));
    const startPromoRotation = () => {
      clearInterval(promoRotation);
      promoRotation = setInterval(() => showPromo(promoIndex + 1), 5500);
    };
    promoSlider?.addEventListener('mouseenter', () => clearInterval(promoRotation));
    promoSlider?.addEventListener('mouseleave', startPromoRotation);
    promoSlider?.addEventListener('focusin', () => clearInterval(promoRotation));
    promoSlider?.addEventListener('focusout', startPromoRotation);
    showPromo(0);
    startPromoRotation();
  }

  const categoryTrack = document.querySelector('#categoryTrack');
  const categoryWindow = document.querySelector('.category-window');
  let categoryOffset = 0;
  const moveCategories = (direction) => {
    if (!categoryTrack || !categoryWindow) return;
    const max = Math.max(0, categoryTrack.scrollWidth - categoryWindow.clientWidth);
    categoryOffset = Math.max(0, Math.min(max, categoryOffset + direction * categoryWindow.clientWidth * 0.72));
    categoryTrack.style.transform = `translateX(-${categoryOffset}px)`;
    const prev = document.querySelector('#categoryPrev');
    const next = document.querySelector('#categoryNext');
    if (prev) prev.disabled = categoryOffset <= 0;
    if (next) next.disabled = categoryOffset >= max - 1;
  };
  document.querySelector('#categoryPrev')?.addEventListener('click', () => moveCategories(-1));
  document.querySelector('#categoryNext')?.addEventListener('click', () => moveCategories(1));
  window.addEventListener('resize', () => { categoryOffset = 0; moveCategories(0); });
  moveCategories(0);

  const categoryMenu = document.querySelector('#categoryMenu');
  const categoryTriggers = [document.querySelector('#allCategoriesToggle'), document.querySelector('#mobileMenuToggle')].filter(Boolean);
  const setCategoryMenuOpen = (isOpen) => {
    if (!categoryMenu) return;
    categoryMenu.hidden = !isOpen;
    categoryTriggers.forEach((trigger) => trigger.setAttribute('aria-expanded', String(isOpen)));
  };
  categoryTriggers.forEach((trigger) => trigger.addEventListener('click', (event) => {
    event.preventDefault();
    setCategoryMenuOpen(categoryMenu?.hidden);
  }));
  document.querySelector('#closeCategoryMenu')?.addEventListener('click', () => setCategoryMenuOpen(false));
  categoryMenu?.addEventListener('click', (event) => {
    if (event.target.closest('a')) setCategoryMenuOpen(false);
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('#categoryMenu') && !categoryTriggers.some((trigger) => trigger.contains(event.target))) setCategoryMenuOpen(false);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') setCategoryMenuOpen(false);
  });

  const cart = new Map();
  const cartCountElement = document.querySelector('#cartCount');
  const cartTotalElement = document.querySelector('#cartTotal');

  const updateCart = () => {
    let totalQuantity = 0;
    let totalAmount = 0;
    const cartItemsElement = document.querySelector('#cartItems');
    if (cartItemsElement) cartItemsElement.replaceChildren();
    cart.forEach((item, cartId) => {
      totalQuantity += item.quantity;
      totalAmount += item.price * item.quantity;
      if (cartItemsElement) {
        const line = document.createElement('div');
        line.className = 'cart-line';
        line.dataset.cartId = cartId;
        const image = document.createElement('img');
        image.src = item.image;
        image.alt = '';
        const details = document.createElement('div');
        details.className = 'cart-line-content';
        const name = document.createElement('p');
        name.className = 'cart-line-name';
        name.textContent = item.name;
        const pay = document.createElement('div');
        pay.className = 'cart-line-pay';
        pay.append('You Pay ');
        const price = document.createElement('strong');
        price.textContent = `₹ ${ (item.price * item.quantity).toLocaleString('en-IN') }`;
        pay.append(price);
        const controls = document.createElement('div');
        controls.className = 'cart-line-controls';
        const variant = document.createElement('span');
        variant.className = 'cart-line-variant';
        variant.textContent = `Variant: ${item.unit || '1 U'}`;
        const stepper = document.createElement('div');
        stepper.className = 'cart-line-stepper';
        stepper.innerHTML = `<button type="button" data-cart-action="decrease" aria-label="Decrease quantity">−</button><span>${item.quantity}</span><button type="button" data-cart-action="increase" aria-label="Increase quantity">+</button><button type="button" class="cart-line-remove" data-cart-action="remove" aria-label="Remove item">×</button>`;
        controls.append(variant, stepper);
        details.append(name, pay, controls);
        line.append(image, details);
        cartItemsElement.append(line);
      }
    });
    if (cartItemsElement && cart.size === 0) {
      const empty = document.createElement('p');
      empty.className = 'cart-empty';
      empty.textContent = 'Your basket is empty.';
      cartItemsElement.append(empty);
    }
    if (cartCountElement) cartCountElement.textContent = String(totalQuantity);
    if (cartTotalElement) cartTotalElement.textContent = totalAmount.toLocaleString('en-IN');
    const subtotalElement = document.querySelector('#cartSubtotal');
    if (subtotalElement) subtotalElement.textContent = totalAmount.toLocaleString('en-IN');
    const itemCountElement = document.querySelector('#cartItemCount');
    if (itemCountElement) itemCountElement.textContent = String(totalQuantity);
  };

  const renderCartControls = (card, quantity) => {
    const addButton = card.querySelector('.add-button');
    if (quantity === 0) {
      const item = cart.get(card.dataset.cartId);
      if (item) cart.delete(card.dataset.cartId);
      card.classList.remove('in-cart');
      if (!addButton) {
        card.querySelector('.quantity-box')?.remove();
        card.querySelector('.remove-button')?.remove();
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'add-button';
        button.innerHTML = '<i class="bi bi-cart-plus-fill" aria-hidden="true"></i> ADD TO CART';
        card.append(button);
      }
      updateCart();
      return;
    }

    const price = Number(card.querySelector('strong')?.textContent.replace(/[^\d.]/g, '') || 0);
    const name = card.querySelector('p')?.textContent.trim() || 'Product';
    card.classList.add('in-cart');
    const item = cart.get(card.dataset.cartId) || { name, price, quantity: 0, image: card.querySelector('img')?.getAttribute('src') || '', unit: card.querySelector('small')?.textContent.trim() || '1 U' };
    item.quantity = quantity;
    cart.set(card.dataset.cartId, item);
    addButton?.remove();

    let controls = card.querySelector('.quantity-box');
    if (!controls) {
      controls = document.createElement('div');
      controls.className = 'quantity-box';
      controls.innerHTML = '<button type="button" class="quantity-trash" data-cart-action="decrease" aria-label="Decrease quantity"><i class="bi bi-trash3-fill" aria-hidden="true"></i></button><span class="quantity-value"></span><button type="button" class="quantity-plus" data-cart-action="increase" aria-label="Increase quantity"><i class="bi bi-plus-lg" aria-hidden="true"></i></button>';
      card.append(controls);
      const removeButton = document.createElement('button');
      removeButton.type = 'button';
      removeButton.className = 'remove-button';
      removeButton.dataset.cartAction = 'remove';
      removeButton.innerHTML = '<i class="bi bi-x-lg" aria-hidden="true"></i><span class="visually-hidden">Remove item</span>';
      controls.append(removeButton);
    }
    controls.querySelector('.quantity-value').textContent = String(quantity);
    updateCart();
  };

  document.querySelectorAll('.product-card').forEach((card, index) => {
    card.dataset.cartId = `product-${index + 1}`;
    const addButton = card.querySelector('.add-button');
    if (addButton) addButton.type = 'button';
    if (addButton) addButton.innerHTML = '<i class="bi bi-cart-plus-fill" aria-hidden="true"></i> ADD TO CART';
  });

  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-cart-action], .add-button');
    if (!button) return;
    const lineId = button.closest('.cart-line')?.dataset.cartId;
    const card = button.closest('.product-card') || [...document.querySelectorAll('.product-card')].find((item) => item.dataset.cartId === lineId);
    if (!card) return;
    const currentQuantity = cart.get(card.dataset.cartId)?.quantity || 0;
    if (button.matches('.add-button') || button.dataset.cartAction === 'increase') {
      renderCartControls(card, currentQuantity + 1);
    } else if (button.dataset.cartAction === 'decrease') {
      renderCartControls(card, Math.max(0, currentQuantity - 1));
    } else if (button.dataset.cartAction === 'remove') {
      renderCartControls(card, 0);
    }
  });

  const cartButton = document.querySelector('.cart');
  const cartPopover = document.querySelector('#cartPopover');
  const cartBackdrop = document.querySelector('#cartBackdrop');
  const closeCartButton = document.querySelector('.cart-close');
  const setCartOpen = (isOpen) => {
    if (!cartButton || !cartPopover) return;
    cartPopover.hidden = !isOpen;
    if (cartBackdrop) cartBackdrop.hidden = !isOpen;
    document.body.classList.toggle('cart-open', isOpen);
    cartButton.setAttribute('aria-expanded', String(isOpen));
  };
  cartButton?.addEventListener('click', () => setCartOpen(cartPopover?.hidden));
  closeCartButton?.addEventListener('click', () => setCartOpen(false));
  cartBackdrop?.addEventListener('click', () => setCartOpen(false));
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-cart-action], .add-button')) return;
    if (!event.target.closest('.cart') && !event.target.closest('#cartPopover')) setCartOpen(false);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') setCartOpen(false);
  });

  const signInTrigger = document.querySelector('#signInTrigger');
  const signInModal = document.querySelector('#signInModal');
  const mobileNumber = document.querySelector('#mobileNumber');
  const continueSignIn = document.querySelector('#continueSignIn');
  const loginMessage = document.querySelector('#loginMessage');
  let previousFocus;
  const setSignInOpen = (isOpen) => {
    if (!signInModal) return;
    signInModal.hidden = !isOpen;
    document.body.classList.toggle('modal-open', isOpen);
    signInTrigger?.setAttribute('aria-expanded', String(isOpen));
    if (isOpen) {
      previousFocus = document.activeElement;
      window.setTimeout(() => mobileNumber?.focus(), 0);
    } else {
      previousFocus?.focus?.();
    }
  };
  signInTrigger?.addEventListener('click', () => setSignInOpen(true));
  document.querySelector('#closeSignIn')?.addEventListener('click', () => setSignInOpen(false));
  signInModal?.addEventListener('click', (event) => {
    if (event.target === signInModal) setSignInOpen(false);
  });
  mobileNumber?.addEventListener('input', () => {
    mobileNumber.value = mobileNumber.value.replace(/\D/g, '').slice(0, 10);
    if (continueSignIn) continueSignIn.disabled = mobileNumber.value.length !== 10;
    if (loginMessage) loginMessage.textContent = '';
  });
  document.querySelector('#signInForm')?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (mobileNumber?.value.length === 10 && loginMessage) {
      loginMessage.textContent = 'Mobile number accepted. OTP sign-in is not connected yet.';
    }
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && signInModal && !signInModal.hidden) setSignInOpen(false);
  });

  document.querySelectorAll('.footer-columns li').forEach((item) => {
    const link = document.createElement('a');
    link.href = '#';
    link.textContent = item.textContent.trim();
    item.replaceChildren(link);
  });
  document.querySelectorAll('.popular-search-row p').forEach((row) => {
    const terms = row.textContent.split('|').map((term) => term.trim()).filter(Boolean);
    row.replaceChildren(...terms.flatMap((term, index) => {
      const link = document.createElement('a');
      link.href = '#';
      link.textContent = term;
      return index < terms.length - 1 ? [link, document.createTextNode(' | ')] : [link];
    }));
  });

  const searchForm = document.querySelector('.search');
  searchForm?.addEventListener('submit', (event) => {
    event.preventDefault();
    const query = document.querySelector('#searchInput').value.trim().toLocaleLowerCase();
    const cards = [...document.querySelectorAll('.product-card')];
    cards.forEach((card) => {
      const match = !query || card.textContent.toLocaleLowerCase().includes(query);
      card.hidden = !match;
    });
    const firstMatch = cards.find((card) => !card.hidden);
    firstMatch?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    if (!firstMatch && query) window.alert(`No products found for “${query}”.`);
  });

  const searchInput = document.querySelector('#searchInput');
  const searchTerms = ['Snacks', 'Milk', 'Dairy', 'Tea', 'Soft Drinks', 'Biscuits', 'Fruits'];
  let termIndex = 0;
  let placeholderTimer;
  const rotatePlaceholder = () => {
    clearInterval(placeholderTimer);
    placeholderTimer = setInterval(() => {
      if (document.activeElement !== searchInput) {
        termIndex = (termIndex + 1) % searchTerms.length;
        searchInput.placeholder = `Search for ${searchTerms[termIndex]}`;
      }
    }, 2200);
  };
  searchInput?.addEventListener('focus', () => clearInterval(placeholderTimer));
  searchInput?.addEventListener('blur', rotatePlaceholder);
  rotatePlaceholder();
})();
