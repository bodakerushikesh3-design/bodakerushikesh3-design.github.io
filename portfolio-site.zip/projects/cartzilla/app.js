const popularProducts = [
  { image: '01 (3).png', name: 'Muesli Fitness Energy, gluten free', price: 2.15, size: '500g' },
  { image: '01.png', name: 'Fresh orange clementine, Spain', price: 3.12, oldPrice: 4.05, size: '1kg', discount: '-30%' },
  { image: '03 (3).png', name: 'Pepsi soda classic, can', price: 0.8, size: '330ml' },
  { image: '04 (2).png', name: 'Mozzarella mini cheese Granarolo', price: 2.99, size: '250g' },
  { image: '05 (1).png', name: 'Coconut, Indonesia', price: 1.24, size: '1 coconut' },
  { image: '02.png', name: 'Pesto sauce Barilla with parmesan and basil', price: 3.95, size: '200g' },
  { image: '07 (1).png', name: 'Fresh mango, Spain', price: 1.99, size: '1 mango' },
  { image: '02 (2).png', name: 'Fresh green asparagus, bunch', price: 2.4, size: '300g' },
];

const specialProducts = [
  { image: '09.png', name: 'Pure virgin olive oil Basso', price: 18.6, size: '1000ml' },
  { image: '06.png', name: 'Fresh pork butt steaks with rosemary', price: 9.15, size: '500g' },
  { image: '11.png', name: 'Fresh red grapefruit', price: 3.4, size: '1kg' },
  { image: '12.png', name: 'Soft cream cheese with greens Exquisa', price: 2.59, size: '150g' },
];

const cart = new Map();
let toastTimer;

function formatPrice(amount) {
  return `$${amount.toFixed(2)}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;',
  })[character]);
}

function createProductCard(product) {
  const card = document.createElement('article');
  card.className = 'product-card';
  card.dataset.name = product.name.toLowerCase();
  card.dataset.productId = product.name;
  card.innerHTML = `
    ${product.discount ? `<span class="product-discount">${product.discount}</span>` : ''}
    <button class="product-like" type="button" aria-label="Add ${escapeHtml(product.name)} to favorites" aria-pressed="false"><i class="bi bi-heart"></i></button>
    <div class="product-image"><img src="assets/${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy"></div>
    <div class="product-details">
      <div class="product-price">${formatPrice(product.price)}${product.oldPrice ? `<del>${formatPrice(product.oldPrice)}</del>` : ''}</div>
      <p class="product-name">${escapeHtml(product.name)}</p>
      <div class="product-size">${escapeHtml(product.size)}</div>
    </div>
    <button class="add-product" type="button" aria-label="Add ${escapeHtml(product.name)} to cart"><i class="bi bi-plus-lg"></i></button>
    <div class="card-add-controls" hidden>
      <button type="button" data-cart-action="decrease" aria-label="Decrease quantity"><i class="bi bi-dash-lg"></i></button>
      <span class="card-quantity">1</span>
      <button type="button" data-cart-action="increase" aria-label="Increase quantity"><i class="bi bi-plus-lg"></i></button>
      <button class="card-remove" type="button" data-cart-action="remove" aria-label="Remove from cart"><i class="bi bi-x-lg"></i></button>
    </div>`;
  return card;
}

function renderProducts(containerId, products) {
  const container = document.getElementById(containerId);
  if (!container) return;
  products.forEach((product) => container.append(createProductCard(product)));
}

function updateProductCards() {
  document.querySelectorAll('.product-card').forEach((card) => {
    const quantity = cart.get(card.dataset.productId)?.quantity || 0;
    const addButton = card.querySelector('.add-product');
    const controls = card.querySelector('.card-add-controls');
    addButton.hidden = quantity > 0;
    controls.hidden = quantity === 0;
    card.querySelector('.card-quantity').textContent = quantity;
    addButton.setAttribute('aria-label', `Add ${card.dataset.productId} to cart`);
  });
}

function updateCartDisplay() {
  const itemCount = [...cart.values()].reduce((total, item) => total + item.quantity, 0);
  const subtotal = [...cart.values()].reduce((total, item) => total + item.product.price * item.quantity, 0);
  document.querySelector('.cart-count').textContent = itemCount;
  document.getElementById('drawerItemCount').textContent = itemCount;
  document.getElementById('cartSubtotal').textContent = formatPrice(subtotal);
  document.getElementById('checkoutButton').disabled = itemCount === 0;
  document.getElementById('viewCartButton').disabled = itemCount === 0;
  document.getElementById('cartShippingMessage').textContent = itemCount === 0
    ? 'Add products to your cart to see your delivery offer.'
    : subtotal >= 50
      ? 'You’ve unlocked free delivery on this order.'
      : `Add ${formatPrice(50 - subtotal)} more to qualify for free delivery.`;

  const drawerItems = document.getElementById('cartDrawerItems');
  if (!itemCount) {
    drawerItems.innerHTML = '<div class="empty-cart"><i class="bi bi-basket2"></i><p>Your basket is empty</p><span>Add a few fresh favorites to get started.</span></div>';
  } else {
    drawerItems.innerHTML = [...cart.entries()].map(([id, item]) => `
      <article class="cart-line">
        <img src="assets/${escapeHtml(item.product.image)}" alt="${escapeHtml(item.product.name)}">
        <div class="cart-line-info">
          <p class="cart-line-name">${escapeHtml(item.product.name)}</p>
          <div class="cart-line-price">${formatPrice(item.product.price * item.quantity)}</div>
          <div class="cart-line-quantity">
            <button type="button" data-drawer-action="decrease" data-product-id="${escapeHtml(id)}" aria-label="Decrease ${escapeHtml(item.product.name)} quantity"><i class="bi bi-dash-lg"></i></button>
            <span>${item.quantity}</span>
            <button type="button" data-drawer-action="increase" data-product-id="${escapeHtml(id)}" aria-label="Increase ${escapeHtml(item.product.name)} quantity"><i class="bi bi-plus-lg"></i></button>
          </div>
        </div>
        <button type="button" class="cart-line-remove" data-drawer-action="remove" data-product-id="${escapeHtml(id)}" aria-label="Remove ${escapeHtml(item.product.name)}"><i class="bi bi-trash3"></i></button>
      </article>`).join('');
  }
  updateProductCards();
}

function showCartFeedback(message) {
  const feedback = document.getElementById('cartFeedback');
  feedback.textContent = message;
  feedback.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => feedback.classList.remove('show'), 1500);
}

function setProductQuantity(product, change) {
  const current = cart.get(product.name)?.quantity || 0;
  const next = current + change;
  if (next <= 0) cart.delete(product.name);
  else cart.set(product.name, { product, quantity: next });
  updateCartDisplay();
}

function setCartOpen(isOpen) {
  if (isOpen && typeof setDeliveryOpen === 'function') setDeliveryOpen(false);
  const drawer = document.getElementById('cartDrawer');
  const backdrop = document.getElementById('cartBackdrop');
  drawer.classList.toggle('open', isOpen);
  drawer.setAttribute('aria-hidden', String(!isOpen));
  drawer.inert = !isOpen;
  backdrop.hidden = !isOpen;
  document.querySelector('.cart-button').setAttribute('aria-expanded', String(isOpen));
  document.body.classList.toggle('cart-open', isOpen);
  if (isOpen) document.getElementById('cartClose').focus();
}

renderProducts('popularProducts', popularProducts);
renderProducts('specialProducts', specialProducts);
updateCartDisplay();

document.addEventListener('click', (event) => {
  const addButton = event.target.closest('.add-product');
  if (addButton) {
    const card = addButton.closest('.product-card');
    const product = [...popularProducts, ...specialProducts].find((item) => item.name === card.dataset.productId);
    setProductQuantity(product, 1);
    showCartFeedback(`${product.name} added to your cart`);
    setCartOpen(true);
    return;
  }

  const cardAction = event.target.closest('[data-cart-action]');
  if (cardAction) {
    const productId = cardAction.closest('.product-card').dataset.productId;
    const product = [...popularProducts, ...specialProducts].find((item) => item.name === productId);
    if (cardAction.dataset.cartAction === 'remove') setProductQuantity(product, -(cart.get(productId)?.quantity || 0));
    else setProductQuantity(product, cardAction.dataset.cartAction === 'increase' ? 1 : -1);
    return;
  }

  const drawerAction = event.target.closest('[data-drawer-action]');
  if (drawerAction) {
    const item = cart.get(drawerAction.dataset.productId);
    if (!item) return;
    if (drawerAction.dataset.drawerAction === 'remove') setProductQuantity(item.product, -item.quantity);
    else setProductQuantity(item.product, drawerAction.dataset.drawerAction === 'increase' ? 1 : -1);
    return;
  }

  const favoriteButton = event.target.closest('.product-like');
  if (favoriteButton) {
    const isActive = favoriteButton.classList.toggle('active');
    favoriteButton.setAttribute('aria-pressed', String(isActive));
    favoriteButton.innerHTML = `<i class="bi ${isActive ? 'bi-heart-fill' : 'bi-heart'}"></i>`;
    return;
  }

  if (event.target.closest('.cart-button')) {
    setCartOpen(true);
    return;
  }
  if (event.target.closest('#cartClose') || event.target === document.getElementById('cartBackdrop')) {
    setCartOpen(false);
    return;
  }
  if (event.target.closest('#viewCartButton') && cart.size) {
    showCartFeedback('Your cart is ready for review.');
    return;
  }
  if (event.target.closest('#checkoutButton') && cart.size) {
    showCartFeedback('Checkout is ready to connect to your store.');
  }
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && document.getElementById('cartDrawer').classList.contains('open')) setCartOpen(false);
});

document.querySelectorAll('.search-form').forEach((form) => {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const searchValue = form.querySelector('input').value.trim().toLowerCase();
    document.querySelectorAll('.search-form input').forEach((input) => { input.value = searchValue; });
    document.querySelectorAll('.product-card').forEach((card) => {
      card.hidden = Boolean(searchValue) && !card.dataset.name.includes(searchValue);
    });
    setMobileSearchOpen(false);
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
  });
});

document.getElementById('newsletterForm').addEventListener('submit', (event) => {
  event.preventDefault();
  document.getElementById('newsletterMessage').textContent = 'Thanks for subscribing!';
  event.currentTarget.reset();
});

const themePicker = document.getElementById('themePicker');
const themeButton = document.querySelector('.theme-btn');

function setThemePickerOpen(isOpen) {
  themePicker.hidden = !isOpen;
  themeButton.setAttribute('aria-expanded', String(isOpen));
}

function applyTheme(theme) {
  const useLightTheme = theme === 'light' || (theme === 'auto' && window.matchMedia('(prefers-color-scheme: light)').matches);
  document.body.classList.toggle('light-theme', useLightTheme);
  document.querySelector('meta[name="theme-color"]').content = useLightTheme ? '#f4f6f8' : '#171c24';
  themePicker.querySelectorAll('[data-theme-choice]').forEach((option) => {
    const selected = option.dataset.themeChoice === theme;
    option.classList.toggle('selected', selected);
    option.setAttribute('aria-checked', String(selected));
  });
}

applyTheme('auto');
themeButton.addEventListener('click', () => setThemePickerOpen(themePicker.hidden));
document.getElementById('customizeButton')?.addEventListener('click', () => {
  setThemePickerOpen(themePicker.hidden);
});
themePicker.querySelectorAll('[data-theme-choice]').forEach((option) => {
  option.addEventListener('click', () => {
    applyTheme(option.dataset.themeChoice);
    setThemePickerOpen(false);
  });
});
document.addEventListener('click', (event) => {
  if (!event.target.closest('.header-actions, #customizeButton')) setThemePickerOpen(false);
});

const mobileSearch = document.getElementById('mobileSearch');
const mobileSearchToggle = document.getElementById('mobileSearchToggle');

function setMobileSearchOpen(isOpen) {
  if (!mobileSearch || !mobileSearchToggle) return;
  mobileSearch.hidden = !isOpen;
  mobileSearchToggle.setAttribute('aria-expanded', String(isOpen));
  if (isOpen) mobileSearch.querySelector('input').focus();
}

mobileSearchToggle?.addEventListener('click', () => setMobileSearchOpen(mobileSearch.hidden));

document.querySelectorAll('.category-list a, .category-nav a').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.product-card').forEach((card) => { card.hidden = false; });
    document.querySelectorAll('.search-form input').forEach((input) => { input.value = ''; });
    setMobileSearchOpen(false);
  });
});

// Let desktop users drag the hero carousel with a mouse.
const heroCarousel = document.getElementById('heroCarousel');
if (heroCarousel) {
  let dragStartX = null;
  let dragged = false;

  heroCarousel.addEventListener('pointerdown', (event) => {
    if (event.pointerType !== 'mouse' || event.button !== 0) return;
    dragStartX = event.clientX;
    dragged = false;
    heroCarousel.setPointerCapture(event.pointerId);
    event.preventDefault();
  });

  heroCarousel.addEventListener('pointerup', (event) => {
    if (dragStartX === null || event.pointerType !== 'mouse') return;
    const distance = event.clientX - dragStartX;
    dragStartX = null;
    if (Math.abs(distance) < 45) return;

    dragged = true;
    const carousel = bootstrap.Carousel.getOrCreateInstance(heroCarousel);
    if (distance < 0) carousel.next();
    else carousel.prev();
    window.setTimeout(() => { dragged = false; }, 0);
  });

  heroCarousel.addEventListener('pointercancel', () => { dragStartX = null; });
  heroCarousel.addEventListener('click', (event) => {
    if (!dragged) return;
    event.preventDefault();
    event.stopPropagation();
    dragged = false;
  }, true);
}

// Enable mouse drag scrolling for the hidden-scrollbar category strip.
const categoryNav = document.querySelector('.category-nav');
if (categoryNav) {
  let pointerStartX = 0;
  let scrollStartX = 0;
  let draggingNav = false;
  let suppressNavClick = false;

  categoryNav.addEventListener('pointerdown', (event) => {
    if (event.pointerType !== 'mouse' || event.button !== 0) return;
    pointerStartX = event.clientX;
    scrollStartX = categoryNav.scrollLeft;
    draggingNav = true;
    suppressNavClick = false;
    categoryNav.setPointerCapture(event.pointerId);
    event.preventDefault();
  });

  categoryNav.addEventListener('pointermove', (event) => {
    if (!draggingNav) return;
    const distance = event.clientX - pointerStartX;
    if (Math.abs(distance) > 4) suppressNavClick = true;
    categoryNav.scrollLeft = scrollStartX - distance;
  });

  const endNavDrag = () => {
    if (!draggingNav) return;
    draggingNav = false;
    window.setTimeout(() => { suppressNavClick = false; }, 0);
  };
  categoryNav.addEventListener('pointerup', endNavDrag);
  categoryNav.addEventListener('pointercancel', endNavDrag);
  categoryNav.addEventListener('click', (event) => {
    if (!suppressNavClick) return;
    event.preventDefault();
    event.stopPropagation();
    suppressNavClick = false;
  }, true);
}

const updateScrollChrome = () => {
  const pageIsScrolled = window.scrollY > 120;
  document.body.classList.toggle('page-scrolled', pageIsScrolled);
  if (pageIsScrolled && !mobileSearch.hidden) setMobileSearchOpen(false);
};
window.addEventListener('scroll', updateScrollChrome, { passive: true });
updateScrollChrome();

// The three collection cards become a swipeable, single-card carousel on phones.
const featureGrid = document.querySelector('.feature-grid');
const featureDots = [...document.querySelectorAll('.feature-dots button')];
if (featureGrid && featureDots.length) {
  const featureSlides = [...featureGrid.children];
  let featureTimer;
  let userInteracting = false;

  const showFeature = (index, behavior = 'smooth') => {
    if (!featureSlides[index] || window.matchMedia('(min-width: 768px)').matches) return;
    featureGrid.scrollTo({ left: index * featureGrid.clientWidth, behavior });
  };

  const updateFeatureDots = () => {
    if (window.matchMedia('(min-width: 768px)').matches) return;
    const slideWidth = featureGrid.clientWidth || 1;
    const activeIndex = Math.min(featureSlides.length - 1, Math.round(featureGrid.scrollLeft / slideWidth));
    featureDots.forEach((dot, index) => {
      const selected = index === activeIndex;
      dot.classList.toggle('active', selected);
      if (selected) dot.setAttribute('aria-current', 'true');
      else dot.removeAttribute('aria-current');
    });
  };

  featureGrid.addEventListener('scroll', updateFeatureDots, { passive: true });
  featureDots.forEach((dot, index) => dot.addEventListener('click', () => showFeature(index)));
  featureGrid.addEventListener('pointerdown', () => { userInteracting = true; }, { passive: true });
  featureGrid.addEventListener('pointerup', () => {
    window.setTimeout(() => { userInteracting = false; }, 7000);
  }, { passive: true });
  featureGrid.addEventListener('pointercancel', () => { userInteracting = false; }, { passive: true });
  featureTimer = window.setInterval(() => {
    if (document.hidden || userInteracting || window.matchMedia('(min-width: 768px)').matches) return;
    const activeIndex = Math.round(featureGrid.scrollLeft / (featureGrid.clientWidth || 1));
    showFeature((activeIndex + 1) % featureSlides.length);
  }, 6000);
  window.addEventListener('resize', updateFeatureDots, { passive: true });
  updateFeatureDots();
}

// Keep the active lifestyle dot in sync with touch swipes on phones.
const lifestyleGrid = document.querySelector('.lifestyle-grid');
const lifestyleDots = [...document.querySelectorAll('.lifestyle-dots button')];
if (lifestyleGrid && lifestyleDots.length) {
  const lifestyleSlides = [...lifestyleGrid.children];
  const isPhoneLayout = () => window.matchMedia('(max-width: 575.98px)').matches;

  const showLifestyle = (index) => {
    if (!isPhoneLayout() || !lifestyleSlides[index]) return;
    lifestyleGrid.scrollTo({ left: index * lifestyleGrid.clientWidth, behavior: 'smooth' });
  };

  const updateLifestyleDots = () => {
    if (!isPhoneLayout()) return;
    const slideWidth = lifestyleGrid.clientWidth || 1;
    const activeIndex = Math.min(lifestyleSlides.length - 1, Math.round(lifestyleGrid.scrollLeft / slideWidth));
    lifestyleDots.forEach((dot, index) => {
      const selected = index === activeIndex;
      dot.classList.toggle('active', selected);
      if (selected) dot.setAttribute('aria-current', 'true');
      else dot.removeAttribute('aria-current');
    });
  };

  lifestyleGrid.addEventListener('scroll', updateLifestyleDots, { passive: true });
  lifestyleDots.forEach((dot, index) => dot.addEventListener('click', () => showLifestyle(index)));
  window.addEventListener('resize', updateLifestyleDots, { passive: true });
  updateLifestyleDots();
}

// Add page dots beneath the swipeable Special products row on tablet and phone widths.
const specialProductTrack = document.getElementById('specialProducts');
const specialProductDots = document.getElementById('specialProductDots');
if (specialProductTrack && specialProductDots) {
  let specialPageTargets = [];

  const buildSpecialProductPages = () => {
    const isSliderLayout = window.matchMedia('(max-width: 1199.98px)').matches;
    const maxScroll = Math.max(0, specialProductTrack.scrollWidth - specialProductTrack.clientWidth);

    if (!isSliderLayout || maxScroll < 2 || !specialProductTrack.clientWidth) {
      specialProductDots.hidden = true;
      specialProductDots.replaceChildren();
      specialPageTargets = [];
      return;
    }

    const pageCount = Math.max(2, Math.ceil(maxScroll / specialProductTrack.clientWidth) + 1);
    specialPageTargets = Array.from({ length: pageCount }, (_, index) => (
      maxScroll * index / (pageCount - 1)
    ));

    if (specialProductDots.children.length !== pageCount) {
      specialProductDots.replaceChildren(...specialPageTargets.map((_, index) => {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.dataset.specialPage = String(index);
        dot.setAttribute('aria-label', `Show Special products page ${index + 1} of ${pageCount}`);
        return dot;
      }));
    }

    specialProductDots.hidden = false;
    updateSpecialProductPage();
  };

  const updateSpecialProductPage = () => {
    if (!specialPageTargets.length) return;
    const activeIndex = specialPageTargets.reduce((closestIndex, target, index) => (
      Math.abs(target - specialProductTrack.scrollLeft) < Math.abs(specialPageTargets[closestIndex] - specialProductTrack.scrollLeft)
        ? index
        : closestIndex
    ), 0);

    [...specialProductDots.children].forEach((dot, index) => {
      const selected = index === activeIndex;
      dot.classList.toggle('active', selected);
      if (selected) dot.setAttribute('aria-current', 'true');
      else dot.removeAttribute('aria-current');
    });
  };

  specialProductTrack.addEventListener('scroll', updateSpecialProductPage, { passive: true });
  specialProductDots.addEventListener('click', (event) => {
    const dot = event.target.closest('[data-special-page]');
    const pageIndex = Number(dot?.dataset.specialPage);
    if (!dot || !Number.isInteger(pageIndex) || pageIndex < 0 || pageIndex >= specialPageTargets.length) return;
    specialProductTrack.scrollTo({ left: specialPageTargets[pageIndex], behavior: 'smooth' });
  });
  window.addEventListener('resize', buildSpecialProductPages, { passive: true });
  buildSpecialProductPages();

  if ('ResizeObserver' in window) {
    new ResizeObserver(buildSpecialProductPages).observe(specialProductTrack);
  }
}

const categoryToggle = document.getElementById('categoriesToggle');
const categoryMenu = document.getElementById('categoryMenu');
const categoryMenuBackdrop = document.getElementById('categoryMenuBackdrop');

function setCategoryMenuOpen(isOpen) {
  if (!categoryToggle || !categoryMenu) return;
  categoryMenu.hidden = !isOpen;
  categoryMenuBackdrop.hidden = !isOpen;
  document.body.classList.toggle('categories-open', isOpen);
  categoryToggle.setAttribute('aria-expanded', String(isOpen));
}

categoryToggle?.addEventListener('click', () => {
  setCategoryMenuOpen(categoryToggle.getAttribute('aria-expanded') !== 'true');
});
categoryMenuBackdrop?.addEventListener('click', () => setCategoryMenuOpen(false));
categoryMenu?.addEventListener('click', (event) => {
  if (event.target.closest('a')) setCategoryMenuOpen(false);
});
document.addEventListener('click', (event) => {
  if (document.body.classList.contains('categories-open') &&
      !event.target.closest('#categoryMenu, #categoriesToggle')) {
    setCategoryMenuOpen(false);
  }
});

const deliveryDrawer = document.getElementById('deliveryDrawer');
const deliveryBackdrop = document.getElementById('deliveryBackdrop');
const deliveryClose = document.getElementById('deliveryClose');

function setDeliveryOpen(isOpen) {
  if (!deliveryDrawer) return;
  if (isOpen) {
    setCartOpen(false);
    setCategoryMenuOpen(false);
  }
  deliveryDrawer.classList.toggle('open', isOpen);
  deliveryDrawer.setAttribute('aria-hidden', String(!isOpen));
  deliveryDrawer.inert = !isOpen;
  deliveryBackdrop.hidden = !isOpen;
  document.body.classList.toggle('delivery-open', isOpen);
  if (isOpen) deliveryClose.focus();
}

document.querySelectorAll('.delivery-open, #deliveryOpenDesktop').forEach((button) => {
  button.addEventListener('click', () => setDeliveryOpen(true));
});
deliveryClose?.addEventListener('click', () => setDeliveryOpen(false));
deliveryBackdrop?.addEventListener('click', () => setDeliveryOpen(false));

document.getElementById('deliveryOpenMenu')?.addEventListener('click', () => {
  const menu = document.getElementById('mobileMenu');
  const offcanvas = bootstrap.Offcanvas.getOrCreateInstance(menu);
  menu.addEventListener('hidden.bs.offcanvas', () => setDeliveryOpen(true), { once: true });
  offcanvas.hide();
});

document.querySelectorAll('[data-delivery-tab]').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('[data-delivery-tab]').forEach((item) => {
      const selected = item === tab;
      item.classList.toggle('active', selected);
      item.setAttribute('aria-selected', String(selected));
    });
    document.querySelectorAll('[data-delivery-panel]').forEach((panel) => {
      panel.hidden = panel.dataset.deliveryPanel !== tab.dataset.deliveryTab;
    });
  });
});

function showDeliveryAddressForm(isOpen) {
  document.getElementById('savedDeliveryAddresses').hidden = isOpen;
  document.getElementById('addressBack').hidden = !isOpen;
  const form = document.getElementById('deliveryAddressForm');
  form.hidden = !isOpen;
  if (isOpen) form.querySelector('select').focus();
}

document.getElementById('addDeliveryAddress')?.addEventListener('click', () => showDeliveryAddressForm(true));
document.getElementById('addressBack')?.addEventListener('click', () => showDeliveryAddressForm(false));
document.getElementById('findDeliveryAddress')?.addEventListener('click', () => {
  document.getElementById('deliveryFeedback').textContent = 'Location lookup is a preview. Enter your address below.';
  document.querySelector('#deliveryAddressForm [name="postal"]').focus();
});

document.getElementById('savedDeliveryAddresses')?.addEventListener('click', (event) => {
  const removeButton = event.target.closest('.remove-address');
  if (removeButton) {
    const row = removeButton.closest('.saved-address-row');
    const wasSelected = row.querySelector('.saved-address').classList.contains('selected');
    row.remove();
    if (wasSelected) {
      const nextAddress = document.querySelector('#savedDeliveryAddresses [data-address-choice]');
      if (nextAddress) nextAddress.click();
      else showDeliveryAddressForm(true);
    }
    return;
  }

  const address = event.target.closest('[data-address-choice]');
  if (!address) return;
  document.querySelectorAll('#savedDeliveryAddresses [data-address-choice]').forEach((item) => {
    const selected = item === address;
    item.classList.toggle('selected', selected);
    item.setAttribute('aria-pressed', String(selected));
  });
  document.getElementById('deliverySummary').innerHTML = `${escapeHtml(address.dataset.addressSummary || 'Sacramento')} <i class="bi bi-chevron-down"></i>`;
});

document.getElementById('deliveryAddressForm')?.addEventListener('submit', (event) => {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  const state = formData.get('state');
  const city = formData.get('city').trim();
  const postal = formData.get('postal').trim();
  const street = formData.get('street').trim();
  const addressName = `Address ${document.querySelectorAll('#savedDeliveryAddresses .saved-address-row').length + 1}`;
  const addressText = `${street}, ${city}, ${state} ${postal}`;
  document.querySelectorAll('#savedDeliveryAddresses [data-address-choice]').forEach((item) => {
    item.classList.remove('selected');
    item.setAttribute('aria-pressed', 'false');
  });
  const savedAddressMarkup = [
    '<div class="saved-address-row">',
    `<button class="saved-address selected" type="button" data-address-choice="${escapeHtml(addressName)}" data-address-summary="${escapeHtml(city)}" aria-pressed="true">`,
    '<span class="address-icon"><i class="bi bi-geo-alt"></i></span>',
    '<span>',
    `<strong>${escapeHtml(addressName)}</strong>`,
    `<small>${escapeHtml(addressText)}</small>`,
    '</span>',
    '<i class="bi bi-check-circle-fill address-check"></i>',
    '</button>',
    `<button class="remove-address" type="button" aria-label="Remove ${escapeHtml(addressName)} address">`,
    '<i class="bi bi-x-lg"></i>',
    '</button>',
    '</div>',
  ].join('');

  document
    .getElementById('savedDeliveryAddresses')
    .insertAdjacentHTML('beforeend', savedAddressMarkup);
  document.getElementById('deliverySummary').innerHTML = `${escapeHtml(city)} <i class="bi bi-chevron-down"></i>`;
  document.getElementById('deliveryFeedback').textContent = 'Address saved for this preview.';
  showDeliveryAddressForm(false);
  const addedAddress = document.querySelector('#savedDeliveryAddresses [data-address-choice].selected');
  if (addedAddress) addedAddress.dataset.addressSummary = city;
});

document.querySelector('.pickup-confirm')?.addEventListener('click', () => {
  document.getElementById('deliverySummary').innerHTML = 'Pickup selected <i class="bi bi-chevron-down"></i>';
  setDeliveryOpen(false);
  showCartFeedback('Pickup selected for this preview.');
});

document.addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  setThemePickerOpen(false);
  setMobileSearchOpen(false);
  setCategoryMenuOpen(false);
  setDeliveryOpen(false);
});
