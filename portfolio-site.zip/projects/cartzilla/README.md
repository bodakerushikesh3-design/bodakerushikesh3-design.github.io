# Cartzilla Bootstrap recreation

Responsive Cartzilla-style grocery storefront made with Bootstrap 5.3.3 and the image assets supplied in the original archive.

## Project files

- `index.html` — storefront sections and Bootstrap-based responsive layout
- `account-signin.html` — responsive sign-in preview
- `styles.css` — desktop, tablet, and phone styling plus the menus and side drawers
- `app.js` — product rendering, search, favorites, quantity controls, cart, delivery options, and newsletter interaction
- `assets/` — local images from the supplied archive

## Run

Open `index.html` in a browser. Bootstrap, Bootstrap Icons, and the sign-in cover image load online, so an internet connection is needed for those items. Product images are stored locally.

The cart, delivery address, and sign-in flows are front-end previews. Connect store, account, and payment services to make those actions persistent.
